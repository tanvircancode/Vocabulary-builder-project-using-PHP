-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 24, 2021 at 08:02 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.1.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `words`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `status`) VALUES
(1, 'asas@ma.com', '$2y$10$N4vUOuADPJ3GTCCcdlf2iuIAxrP3U75PRx5DZWOUvy25Up8tOojUu', 1),
(5, 'asas@gmail.com', '$2y$10$9Z/Oo4QnnqrdMQcleJqSLujHIQJ2n3gatwCwxjbR5yJz7wSK2e50O', 1),
(6, 'tan@gmail.com', '$2y$10$0rPKob4ljGOIQ5tikzdX4.SljhBPftvoFve1pItedx2F6RMBuPwoG', 1),
(8, 'tanv@gmail.com', '$2y$10$/.7WSMjc1YgMJ8iAhxkVD.6w5cyrQ6Tzv2eAj8um5uQeLf71fYKY.', 1),
(10, 't@mail.com', '$2y$10$J4MroX8kdSnUBvB7033oZugLgIcp4VMEzNqZFzZT4KMRrLTARWgmO', 1),
(11, 'yafee@gmail.com', '$2y$10$bxW1Gv8M2XRjQQP5kQ3wVOAwWiep6fwfC/LRsSwsJGWM9HHJIbuQC', 1),
(12, 's@gmail.com', '$2y$10$xNNzKUEY518xB8dQHhf4P.r9sT6VwVoWSLwOx2c8kdrWvlB8rWUYu', 1),
(13, 'l@mail.com', '$2y$10$sBWzz8VzJhBsX6asv4os0ehYAJabPo5bkPYRdGkEyAbSVGgXw5yCS', 1);

-- --------------------------------------------------------

--
-- Table structure for table `words`
--

CREATE TABLE `words` (
  `id` int(11) NOT NULL,
  `word` varchar(255) NOT NULL,
  `meaning` text NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `words`
--

INSERT INTO `words` (`id`, `word`, `meaning`, `user_id`) VALUES
(10, 'Love', 'ভালোবাসা', 8),
(11, 'Interest', 'সুদ', 11),
(12, 'Development', 'উন্নয়ন', 11),
(13, 'Situation', 'অবস্থা', 11),
(14, 'Player', 'খেলোয়াড়', 8),
(15, 'Exercise', 'ব্যায়াম', 8),
(16, 'Cold', 'ঠান্ডা', 8),
(17, 'Cow', 'গরু', 12),
(18, 'Think', 'চিন্তা', 12),
(19, 'Tea', 'চা', 13),
(22, 'Parents', 'পিতামাতা', 13),
(23, 'Dog', 'কুকুর', 11),
(24, 'Vehicle', 'যানবাহন', 11),
(25, 'Temperature', 'তাপমাত্রা', 11),
(26, 'Ass', 'গাঁধা', 13),
(27, 'Ball', 'বল', 13),
(28, 'Cat', 'বিড়াল', 13),
(29, 'Dog', 'কুকুর', 13),
(30, 'Doll', 'পুতুল', 13),
(31, 'Birthday', 'জন্মদিন', 13),
(32, 'Nature', 'প্রকৃতি', 13),
(33, 'True', 'সত্য', 13),
(34, 'Task', 'কাজ', 13),
(35, 'Love', 'ভালোবাসা', 11);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `words`
--
ALTER TABLE `words`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_words` (`user_id`,`word`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `words`
--
ALTER TABLE `words`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
